from flask import Flask, request
from twilio.twiml.messaging_response import MessagingResponse

app = Flask(__name__)

@app.route("/")
def hello():
    return "Hello, World!"

@app.route("/sms", methods=['POST'])
def sms_reply():
    
    user_msg = request.values.get('Body', '').lower()
    ## Init bot response
    bot_resp= MessagingResponse()
    msg = bot_resp.message()
    # Applying bot logic
    if 'hello' in user_msg:
        msg.body(" _Hi there !_ *I am Exam Bot* . ")
        msg.body("I know about following exams > \n *1)* NDA \n *2)* CDS \n *3)* GATE \n *4* for daily updates (connect) \n (if there is bracket then use this word and send to me )")
    elif 'nda' in user_msg:
        msg.body("*1)*  Basic Info \n *2)*  Official Site \n *3)*  Detail Video \n *4)*  How To Apply \n *5)*  Free Study Material \n *6)* Paid Study Material")
        msg.body(" . \n  *_You Have to choose above option and send to me_* ")  
    elif 'basic info' in user_msg:
        msg.body(" *NDA is a national-level defence entrance exam* conducted by \t *the Union Public Service Commission (UPSC)* _twice a year_ .The exam is conducted to recruit the candidates for the Army, Navy and Air Force wings of the Indian Naval Academy Course (INAC) and National Defence Academy (NDA) \n")
        msg.body(" .\n .\n A) *Full-Form of NDA* : National Defence Academy Exam \n \n B) *Conducting Body* : Union Public Service Commission (UPSC) \n \n C) *Frequency* : Twice a Year \n \n D) *Exam Type* : National Level \n \n E) *Eligibility Criteria* : Unmarried Male/Female candidates who have passed Class XII from a recognized board \n")
        msg.body(" . \n .\n F) *Mode of Application* : Online \n \n G) *Exam Mode* : Offline \n \n H) *Duration:* \n \n \t 1) _Mathematics_ : 2 hours 30 minutes \n \n \t 2) _General Ability Test_ : 2 hours 30 minutes \n \n I) *Number of cities for exam centres* : 75 \n \n J) *Selection Process* : Written Test ,SSB Interview")
    elif 'official site' in user_msg:
        msg.body('www.upsc.gov.in')
    elif 'detail video' in user_msg:
        msg.body('https://youtu.be/ealtyFK3YXE')    
    elif 'how to apply' in user_msg:
        msg.body('https://youtu.be/YwelU33cBtc') 
    elif 'free study material' in user_msg:
        msg.body(" *_You have to googled below_* : \n *1.* MATHS JUGAAD SE  \n *2.* Dristhi IAS \n *3.* ARPIT CHOUDHARY\n *4.* EXAMPUR DEFENCE WARRIORS \n *5.* RS SIR \n *6.* TUTORS ACADEMY\n *7.* CADETS DEFENCE ACADEMY\n *8.* NEHA AGARWAL MATHEMATICALLY INCLINED\n *9.* ARPIT CHAUDHARY \n *10.* GLOBAL DEFENCE ACADEMY \n *11.* TEXTBOOK.com\n *12.* UNACADEMY WARRIORS \n *13.* GRADEUP DEFENCE \n *14.* GRADEUP WARRIORS \ *15.* NEXT EXAM \n *16.* AMIT SEN GUPTA\n *17.* RAVI STUDY IQ\n *18.* SUMIT SIR \n *19.* OVERSIMPLIFIED ")    
    elif 'paid study material' in user_msg:
        msg.body(" *1.* BYJU'S \n *2.* Major Kalshi classes ")
    elif 'cds' in user_msg:
        msg.body("*1)* CDS info (info)  \n *2)* Official Site of CDS Exam \n *3)* Video of CDS (video) \n *4)* CDS How To Apply Exam CDS (apply) \n *5)* Free Material \n *6)* CDS Paid Study Material")
        msg.body(".\n *You Have to choose above option and send to me* ")  
    elif 'info' in user_msg:
        msg.body(" The full form of *CDS* is \n *Combined Defence Services Examination*.  \n It is under the Union Public Service Commission. \n *CDS qualified* applicants will be eligible for *admissions* to *Indian Military Academy*, *Indian Naval Academy* , *Air Force Academy* , and *Officers Training Academy* ")
        msg.body(" . \n .\n 1) *CDS Full Form* : Combined Defence Services Exam \n \n 2) *Conducting Body* : Union Public Service Commission (UPSC) \n \n 3) *Frequency* : Twice a Year \n\n 4) *Exam Type* : National Level \n\n 5) *Application Fees* : \n \t A) UR/ OBC - Rs 200 \n \t B) Female - Exempted \n \t C) SC/ST - Exempted \n \n 6) *Exam Mode :* Offline \n \n 7) *Exam Duration :* 2 Hours \n \n 8) *Language :* English and Hindi ")        
    elif 'official site of cds exam' in user_msg:
        msg.body('www.upsc.gov.in')
    elif 'video' in user_msg:
        msg.body('1) https://www.youtube.com/watch?v=pr03pvxSsSo')         
        msg.body('.\n 2) https://www.youtube.com/watch?v=c1WDucMFSSk')   
    elif 'apply' in user_msg:
        msg.body('https://youtu.be/QVvfZXPQlw0')
    elif 'free material' in user_msg:
        msg.body(" *_You Have to googled below_* : \n *1.* SSBCrackExams   \n *2.* Defence Direct Education \n *3.* wifistudy Defence Exams \n *4.* DefenceGyan.Com \n *5.* Defence Exams Quest ")    
    elif 'paid study material' in user_msg:
        msg.body(" *1.* BYJU'S \n *2.* Major Kalshi classes \n *3.* Doon Indian Defence Academy (Doon IDA), Dehradun ")
    elif 'gate' in user_msg:
        msg.body("*1)* Detail Gate (about) \n *2)* Official Site Gate (Website)  \n *3)* Gate Detail Info Video (youtube) \n *4)*  How To Apply Gate (application) \n *5)* Free Material Gate (free) \n *6)*  Paid Material Gate (paid) ")
        msg.body(".\n *You Have to choose above option and send to me* ")  
    elif 'about' in user_msg:
        msg.body(" Graduate Aptitude Test in Engineering or commonly known as GATE is a national level engineering entrance examination and a number of students participate for M.Tech admissions or PSU recruitments ")
        msg.body(". \n 1) *Examination Mode :* Computer Based Test (Online) \n \n 2) *Duration :* 3 Hours \n \n 4) *Number of Papers in GATE 2022 :*  29 Papers \n \n 5) *Section :*  \n \t A) General Aptitude (GA) \n \t B) Candidate Selected Subject \n \n 6) *Type of Questions :*  \n \t A) Multiple Choice Questions (MCQs) \n \t B) Multiple Select Questions (MSQs) \n \t C) Numerical Answer Type (NAT) Questions \n \n 7) *Design of Questions :*  \n \t 👉 The questions are designed to test the listed abilities \n \t 👉 Application \n \t 👉 Analysis \n \t 👉 Comprehension \n \t 👉 Recall \n \t 👉 Synthesis  ")
        msg.body(". \n.\n 8) *Number of Questions :* 65 Questions (including 10 questions from General Aptitude) \n \n 9) *Distribution of Questions :*  \n \t A) Engineering Mathematics - 13 Marks \n \t B) Subject Questions - 72 Marks \n \t C) General Aptitude - 15 Marks \n \n 10) *Total Marks :* 100 \n \n 11) *Marking Scheme :* \n *_All of the questions will be worth 1 or 2 marks_* \n \t  *Negative Marking:* (Two types of MCQs) \n\n \t\t  *MCQs - 1* : mark for each correct answer; 1/3 mark will be deducted for every wrong answer.\n\t\t *MCQs - 2* : marks for each correct answer; 2/3 mark will be deducted for every incorrect response. \n There is no negative marking for Numerical Answer Type (NAT) questions . NO negative marking for MSQ & NAT. ")
    elif 'website' in user_msg:
        msg.body('https://gate.iitkgp.ac.in')
    elif 'youtube' in user_msg:
        msg.body('https://www.youtube.com/watch?v=9e3j73otbek')                 
    elif 'application' in user_msg:
        msg.body('https://www.youtube.com/watch?v=3brcBxbIgg8')
    elif 'free' in user_msg:
        msg.body(" *_You Have to googled below_* : \n *1.* Unacademy and NPTEL YouTube Channels   \n *2.* Gradeup \n *3.* GATE Academy  \n *4.* GATEMATIC Education \n *5.* GATE Lectures by Ravindrababu Ravula ")    
    elif 'paid' in user_msg:
        msg.body(" *1.* BYJU'S \n *2.* GATE ACADEMY Learning  \n *3.* Unacademy ")    
    elif 'who' in user_msg:
        msg.body('I am created by Kaushal Gore using Flask+NGRok and Twilio')
    elif 'connect' in user_msg:
        msg.body('https://chat.whatsapp.com/LMwlLat2hfqJ1deVBR9Yj3')
    else:
        msg.body("Sorry, I didn't get what you have said!")
    return str(bot_resp)

if __name__ == "__main__":
    app.run(debug=True)
